package com.ubs.Exception;

public class EODPositionException extends Exception {

	private static final long serialVersionUID = 1L;

	public EODPositionException() {
	}

	public EODPositionException(Throwable cause) {
		super(cause);
	}
}
