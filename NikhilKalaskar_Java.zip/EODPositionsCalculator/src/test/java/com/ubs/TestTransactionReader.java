package com.ubs;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

import com.ubs.EODPositionsCalculator.beans.Transaction;
import com.ubs.EODPositionsCalculator.utils.TransactionReader;
import com.ubs.Exception.EODPositionException;

public class TestTransactionReader {
	@Test
	public void testReadPositions() throws EODPositionException {
		TransactionReader reader = new TransactionReader();
		List<Transaction> transactions = reader.readTransactions();
		assertNotNull(transactions);
	}
}
