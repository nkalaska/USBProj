package com.ubs;

import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.EODPositionsCalculator.Main;
import com.ubs.EODPositionsCalculator.beans.Position;
import com.ubs.EODPositionsCalculator.beans.PositionKey;
import com.ubs.EODPositionsCalculator.beans.Transaction;
import com.ubs.EODPositionsCalculator.utils.PositionReader;
import com.ubs.EODPositionsCalculator.utils.TransactionReader;
import com.ubs.Exception.EODPositionException;

public class TestEODPositionCalculator {

	List<Transaction> transactions;
	Map<PositionKey, Position> initialPositions;

	@Before
	public void setup() throws EODPositionException {
		transactions = TransactionReader.readTransactions();
		initialPositions = PositionReader.readPositions();
	}

	@Test
	public void testCalculateAndWriteEODPositions() throws EODPositionException {
		boolean flag = Main.calculateAndWriteEODPositions(transactions, initialPositions);
		assertTrue(flag);
	}
}
