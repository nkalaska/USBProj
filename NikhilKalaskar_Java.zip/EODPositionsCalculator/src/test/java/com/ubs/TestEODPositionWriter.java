package com.ubs;

import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.EODPositionsCalculator.beans.EODPosition;
import com.ubs.EODPositionsCalculator.beans.PositionKey;
import com.ubs.EODPositionsCalculator.utils.EODPositionsWriter;
import com.ubs.Exception.EODPositionException;

public class TestEODPositionWriter {

	Map<PositionKey, EODPosition> eodPositions;

	@Before
	public void setup() {
		eodPositions = new HashMap<PositionKey, EODPosition>();
		eodPositions.put(new PositionKey("xyz", "101", "I"), new EODPosition("xyz", "101", "I", 1000, 1000));
		eodPositions.put(new PositionKey("abc", "102", "E"), new EODPosition("abc", "102", "E", 2000, 5));
	}

	@Test
	public void testWritePositionsData() throws EODPositionException {
		EODPositionsWriter writer = new EODPositionsWriter();
		boolean flag = writer.writePositionsData(eodPositions);
		assertTrue(flag);
	}
}
