package com.ubs;

import static org.junit.Assert.assertNotNull;

import java.util.Map;

import org.junit.Test;

import com.ubs.EODPositionsCalculator.beans.Position;
import com.ubs.EODPositionsCalculator.beans.PositionKey;
import com.ubs.EODPositionsCalculator.utils.PositionReader;
import com.ubs.Exception.EODPositionException;

public class TestPositionReader {
	@Test
	public void testReadPositions() throws EODPositionException {
		PositionReader reader = new PositionReader();
		Map<PositionKey, Position> positions = reader.readPositions();
		assertNotNull(positions);
	}
}
